package com.example.roomatch.viewmodel;

import android.net.Uri;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.roomatch.model.repository.ApartmentRepository;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;


public class OwnerViewModel extends ViewModel {
    private final ApartmentRepository repository;
    private final String currentUserId;
    private final MutableLiveData<String> toastMessage = new MutableLiveData<>();
    private final MutableLiveData<Boolean> publishSuccess = new MutableLiveData<>();

    public OwnerViewModel(ApartmentRepository repository, String userId) {
        this.repository = repository;
        this.currentUserId = userId;
    }

    public MutableLiveData<String> getToastMessage() { return toastMessage; }
    public MutableLiveData<Boolean> getPublishSuccess() { return publishSuccess; }
    public String getCurrentUserId() { return currentUserId; }

    public void publishApartment(String city, String street, String houseNumStr, String priceStr,
                                 String roommatesStr, String description, Uri imageUri) {
        String validationError = validateInputs(city, street, houseNumStr, priceStr, roommatesStr, description);
        if (validationError != null) {
            toastMessage.setValue(validationError);
            return;
        }

        int houseNumber, price, roommatesNeeded;
        try {
            houseNumber = Integer.parseInt(houseNumStr);
            price = Integer.parseInt(priceStr);
            roommatesNeeded = Integer.parseInt(roommatesStr);
        } catch (NumberFormatException e) {
            toastMessage.setValue("מספרים לא תקינים בשדות כמות/מחיר/מספר בית");
            return;
        }

        Map<String, Object> apt = createApartmentMap(currentUserId, city, street, houseNumber, price,
                roommatesNeeded, description, "");
        repository.uploadApartment(apt, imageUri)
                .addOnSuccessListener(docRef -> {
                    toastMessage.setValue("הדירה פורסמה");
                    publishSuccess.setValue(true);
                })
                .addOnFailureListener(e -> toastMessage.setValue("שגיאה בפרסום: " + e.getMessage()));
    }

    public void updateApartment(String apartmentId, String city, String street, String houseNumStr,
                                String priceStr, String roommatesStr, String description, Uri imageUri) {
        String validationError = validateInputs(city, street, houseNumStr, priceStr, roommatesStr, description);
        if (validationError != null) {
            toastMessage.setValue(validationError);
            return;
        }

        int houseNumber, price, roommatesNeeded;
        try {
            houseNumber = Integer.parseInt(houseNumStr);
            price = Integer.parseInt(priceStr);
            roommatesNeeded = Integer.parseInt(roommatesStr);
        } catch (NumberFormatException e) {
            toastMessage.setValue("מספרים לא תקינים בשדות כמות/מחיר/מספר בית");
            return;
        }

        Map<String, Object> updatedApt = createApartmentMap(currentUserId, city, street, houseNumber, price,
                roommatesNeeded, description, "");
        repository.updateApartment(apartmentId, updatedApt, imageUri)
                .addOnSuccessListener(aVoid -> {
                    toastMessage.setValue("הדירה עודכנה");
                    publishSuccess.setValue(true);
                })
                .addOnFailureListener(e -> {
                    if (e instanceof IllegalArgumentException) {
                        toastMessage.setValue("שגיאה: הדירה לא נמצאה");
                    } else {
                        toastMessage.setValue("שגיאה בעדכון: " + e.getMessage());
                    }
                });
    }

    public Task<QuerySnapshot> getApartments() {
        return repository.getApartments();
    }

    public void deleteApartment(String apartmentId) {
        repository.deleteApartment(apartmentId)
                .addOnSuccessListener(aVoid -> toastMessage.setValue("הדירה נמחקה"))
                .addOnFailureListener(e -> toastMessage.setValue("שגיאה במחיקה: " + e.getMessage()));
    }

    private String validateInputs(String city, String street, String houseNumStr, String priceStr,
                                  String roommatesStr, String description) {
        if (city == null || city.isEmpty() || street == null || street.isEmpty() ||
                houseNumStr == null || houseNumStr.isEmpty() || priceStr == null || priceStr.isEmpty() ||
                roommatesStr == null || roommatesStr.isEmpty() || description == null || description.isEmpty()) {
            return "כל השדות חייבים להיות מלאים";
        }

        try {
            int houseNumber = Integer.parseInt(houseNumStr);
            int price = Integer.parseInt(priceStr);
            int roommates = Integer.parseInt(roommatesStr);

            if (houseNumber < 0 || price < 0 || roommates < 0) {
                return "שדות מספריים חייבים להיות חיוביים";
            }
        } catch (NumberFormatException e) {
            return "מספרים לא תקינים בשדות כמות/מחיר/מספר בית";
        }

        return null;
    }

    private Map<String, Object> createApartmentMap(String ownerId, String city, String street,
                                                   int houseNumber, int price, int roommatesNeeded,
                                                   String description, String imageUrl) {
        Map<String, Object> apt = new HashMap<>();
        apt.put("ownerId", ownerId);
        apt.put("city", city);
        apt.put("street", street);
        apt.put("houseNumber", houseNumber);
        apt.put("price", price);
        apt.put("roommatesNeeded", roommatesNeeded);
        apt.put("description", description);
        apt.put("imageUrl", imageUrl);
        return apt;
    }
}