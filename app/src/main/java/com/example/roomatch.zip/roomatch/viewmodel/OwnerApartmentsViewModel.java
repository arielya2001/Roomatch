package com.example.roomatch.viewmodel;

import android.net.Uri;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.roomatch.model.repository.ApartmentRepository;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class OwnerApartmentsViewModel extends ViewModel {

    private final ApartmentRepository repository;
    private final MutableLiveData<List<Map<String, Object>>> allApartments = new MutableLiveData<>(new ArrayList<>());
    private final MutableLiveData<List<Map<String, Object>>> filteredApartments = new MutableLiveData<>(new ArrayList<>());
    private final MutableLiveData<String> toastMessage = new MutableLiveData<>();

    public OwnerApartmentsViewModel(ApartmentRepository repository) {
        this.repository = repository;
    }

    public LiveData<List<Map<String, Object>>> getFilteredApartments() {
        return filteredApartments;
    }

    public LiveData<String> getToastMessage() {
        return toastMessage;
    }

    public String getCurrentUserId() {
        return repository.getCurrentUserId(); // Assuming repository has access to FirebaseAuth
    }

    public void loadApartments(String ownerId) {
        repository.getApartmentsByOwnerId(ownerId).addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot snapshot) {
                List<Map<String, Object>> list = new ArrayList<>();
                for (DocumentSnapshot doc : snapshot.getDocuments()) {
                    Map<String, Object> data = doc.getData();
                    if (data != null) {
                        data.put("id", doc.getId()); // Add the document ID to the map
                        list.add(data);
                    }
                }
                allApartments.setValue(list);
                filteredApartments.setValue(new ArrayList<>(list));
            }
        }).addOnFailureListener(e -> toastMessage.setValue("שגיאה בטעינת הדירות"));
    }

    public void applyFilter(String field, boolean ascending) {
        List<Map<String, Object>> apartments = new ArrayList<>(Objects.requireNonNull(allApartments.getValue()));
        apartments.sort((a, b) -> {
            Comparable valA = (Comparable) a.get(field);
            Comparable valB = (Comparable) b.get(field);
            if (valA == null || valB == null) return 0;
            return ascending ? valA.compareTo(valB) : valB.compareTo(valA);
        });
        filteredApartments.setValue(apartments);
    }

    public void resetFilter() {
        filteredApartments.setValue(new ArrayList<>(Objects.requireNonNull(allApartments.getValue())));
    }

    public void searchApartments(String query) {
        List<Map<String, Object>> result = new ArrayList<>();
        String q = query.toLowerCase();
        for (Map<String, Object> apt : Objects.requireNonNull(allApartments.getValue())) {
            if (apt.values().stream().anyMatch(val -> val != null && val.toString().toLowerCase().contains(q))) {
                result.add(apt);
            }
        }
        filteredApartments.setValue(result);
    }

    public void updateApartment(String apartmentId, String city, String street, String houseNumStr,
                                String priceStr, String roommatesStr, String description, Uri imageUri) {
        String validationError = validateInputs(city, street, houseNumStr, priceStr, roommatesStr, description);
        if (validationError != null) {
            toastMessage.setValue(validationError);
            return;
        }

        int houseNumber, price, roommatesNeeded;
        try {
            houseNumber = Integer.parseInt(houseNumStr);
            price = Integer.parseInt(priceStr);
            roommatesNeeded = Integer.parseInt(roommatesStr);
        } catch (NumberFormatException e) {
            toastMessage.setValue("מספרים לא תקינים בשדות כמות/מחיר/מספר בית");
            return;
        }

        Map<String, Object> updatedApt = createApartmentMap(getCurrentUserId(), city, street, houseNumber, price,
                roommatesNeeded, description, "");
        repository.updateApartment(apartmentId, updatedApt, imageUri)
                .addOnSuccessListener(aVoid -> {
                    toastMessage.setValue("דירה עודכנה בהצלחה");
                    loadApartments(getCurrentUserId()); // Refresh the list
                })
                .addOnFailureListener(e -> {
                    if (e instanceof IllegalArgumentException) {
                        toastMessage.setValue("שגיאה: הדירה לא נמצאה");
                    } else {
                        toastMessage.setValue("שגיאה בעדכון: " + e.getMessage());
                    }
                });
    }

    private String validateInputs(String city, String street, String houseNumStr, String priceStr,
                                  String roommatesStr, String description) {
        if (city == null || city.isEmpty() || street == null || street.isEmpty() ||
                houseNumStr == null || houseNumStr.isEmpty() || priceStr == null || priceStr.isEmpty() ||
                roommatesStr == null || roommatesStr.isEmpty() || description == null || description.isEmpty()) {
            return "כל השדות חייבים להיות מלאים";
        }

        try {
            int houseNumber = Integer.parseInt(houseNumStr);
            int price = Integer.parseInt(priceStr);
            int roommates = Integer.parseInt(roommatesStr);

            if (houseNumber < 0 || price < 0 || roommates < 0) {
                return "שדות מספריים חייבים להיות חיוביים";
            }
        } catch (NumberFormatException e) {
            return "מספרים לא תקינים בשדות כמות/מחיר/מספר בית";
        }

        return null;
    }

    private Map<String, Object> createApartmentMap(String ownerId, String city, String street,
                                                   int houseNumber, int price, int roommatesNeeded,
                                                   String description, String imageUrl) {
        Map<String, Object> apt = new HashMap<>();
        apt.put("ownerId", ownerId);
        apt.put("city", city);
        apt.put("street", street);
        apt.put("houseNumber", houseNumber);
        apt.put("price", price);
        apt.put("roommatesNeeded", roommatesNeeded);
        apt.put("description", description);
        apt.put("imageUrl", imageUrl);
        return apt;
    }
}