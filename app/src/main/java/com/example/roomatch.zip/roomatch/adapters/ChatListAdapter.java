package com.example.roomatch.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.roomatch.R;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

public class ChatListAdapter extends RecyclerView.Adapter<ChatListAdapter.ChatViewHolder> {

    private List<Map<String, Object>> chats;
    private OnChatClickListener listener;

    public interface OnChatClickListener {
        void onChatClick(String fromUserId, String apartmentId);
    }

    public ChatListAdapter(List<Map<String, Object>> chats, OnChatClickListener listener) {
        this.chats = chats;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ChatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_chat_list, parent, false);
        return new ChatViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChatViewHolder holder, int position) {
        Map<String, Object> chat = chats.get(position);
        String fromUserId = (String) chat.get("fromUserId");
        String apartmentId = (String) chat.get("apartmentId");
        String lastMessage = (String) chat.get("lastMessage");
        Long timestamp = (Long) chat.get("timestamp");
        String time = new SimpleDateFormat("HH:mm").format(new java.util.Date(timestamp));

        holder.textViewSender.setText("מאת: " + fromUserId);
        holder.textViewApartment.setText("דירה: " + apartmentId);
        holder.textViewMessage.setText("הודעה אחרונה: " + lastMessage);
        holder.textViewTime.setText("שעה: " + time);
        holder.buttonOpenChat.setOnClickListener(v -> listener.onChatClick(fromUserId, apartmentId));
    }

    @Override
    public int getItemCount() {
        return chats.size();
    }

    static class ChatViewHolder extends RecyclerView.ViewHolder {
        TextView textViewSender, textViewApartment, textViewMessage, textViewTime;
        Button buttonOpenChat;

        public ChatViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewSender = itemView.findViewById(R.id.textViewSender);
            textViewApartment = itemView.findViewById(R.id.textViewApartment);
            textViewMessage = itemView.findViewById(R.id.textViewMessage);
            textViewTime = itemView.findViewById(R.id.textViewTime);
            buttonOpenChat = itemView.findViewById(R.id.buttonOpenChat);
        }
    }
}