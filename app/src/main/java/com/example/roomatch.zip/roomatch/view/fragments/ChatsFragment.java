package com.example.roomatch.view.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.roomatch.R;
import com.example.roomatch.adapters.ChatListAdapter;
import com.example.roomatch.utils.ChatUtil;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChatsFragment extends Fragment {

    private RecyclerView recyclerView;
    private ChatListAdapter adapter;
    private List<Map<String, Object>> chats = new ArrayList<>();
    private FirebaseFirestore db;
    private FirebaseAuth auth;

    public ChatsFragment() {}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_chats, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();

        recyclerView = view.findViewById(R.id.recyclerViewChats);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        adapter = new ChatListAdapter(chats, this::openChat);
        recyclerView.setAdapter(adapter);

        loadChats();
    }

    private void loadChats() {
        String uid = auth.getCurrentUser() != null ? auth.getCurrentUser().getUid() : null;
        if (uid == null) return;

        db.collectionGroup("chat")
                .whereEqualTo("toUserId", uid)
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .get()
                .addOnSuccessListener(snapshot -> {
                    chats.clear();
                    Map<String, Map<String, Object>> uniqueChats = new HashMap<>();
                    for (QueryDocumentSnapshot doc : snapshot) {
                        String fromUserId = doc.getString("fromUserId");
                        String apartmentId = doc.getString("apartmentId");
                        String chatKey = fromUserId + "_" + apartmentId; // ייחודי לפי משתמש ודירה
                        if (!uniqueChats.containsKey(chatKey)) {
                            Map<String, Object> chat = new HashMap<>();
                            chat.put("fromUserId", fromUserId);
                            chat.put("apartmentId", apartmentId);
                            chat.put("lastMessage", doc.getString("text"));
                            chat.put("timestamp", doc.getLong("timestamp"));
                            uniqueChats.put(chatKey, chat);
                        }
                    }
                    chats.addAll(uniqueChats.values());
                    if (chats.isEmpty()) {
                        Toast.makeText(getContext(), "אין צ'אטים זמינים", Toast.LENGTH_SHORT).show();
                    }
                    adapter.notifyDataSetChanged();
                })
                .addOnFailureListener(e -> {
                    Log.e("ChatsFragment", "Error loading chats: " + e.getMessage());
                    Toast.makeText(getContext(), "שגיאה בטעינת צ'אטים: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
    }

    private void openChat(String fromUserId, String apartmentId) {
        ChatFragment chatFragment = new ChatFragment(fromUserId, apartmentId);
        requireActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragmentContainer, chatFragment)
                .addToBackStack(null)
                .commit();
    }
}