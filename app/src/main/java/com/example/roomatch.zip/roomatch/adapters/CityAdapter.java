package com.example.roomatch.adapters;

public class CityAdapter {
}
