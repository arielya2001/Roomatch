package com.example.roomatch.viewmodel;

public class SearchViewModel {
}
