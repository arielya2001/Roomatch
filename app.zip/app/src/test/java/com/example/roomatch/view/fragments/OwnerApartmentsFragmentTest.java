package com.example.roomatch.view.fragments;

import android.os.Build;
import android.widget.Spinner;

import androidx.recyclerview.widget.RecyclerView;

import com.example.roomatch.R;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.mockito.Mockito;
import org.robolectric.Robolectric;
import org.robolectric.androidx.fragment.FragmentController;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

import java.util.*;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
public class OwnerApartmentsFragmentTest {

    private OwnerApartmentsFragment fragment;

    @Before
    public void setUp() {
        // שימו לב ל‑import החדש – androidx FragmentController
        FragmentController<OwnerApartmentsFragment> fc =
                FragmentController.of(new OwnerApartmentsFragment());
        fc.create().start().resume();
        fragment = fc.get();
    }

    @Test
    public void searchApartments_filtersCorrectly() {
        Map<String,Object> telAviv = Map.of("city","Tel‑Aviv","street","Dizengoff");
        Map<String,Object> haifa   = Map.of("city","Haifa","street","Herzl");
        fragment.getAllApartments().addAll(Arrays.asList(telAviv, haifa));

        fragment.callSearch("haifa");

        assertEquals(1, fragment.getApartmentList().size());
        assertEquals("Haifa", fragment.getApartmentList().get(0).get("city"));
    }

    @Test
    public void applyFilter_sortsByPriceAscending() {
        Map<String,Object> cheap     = Map.of("price", 1000);
        Map<String,Object> expensive = Map.of("price", 5000);
        fragment.getApartmentList().addAll(Arrays.asList(expensive, cheap));

        Spinner sField = fragment.requireView().findViewById(R.id.spinnerOwnerFilterField);
        Spinner sOrder = fragment.requireView().findViewById(R.id.spinnerOwnerOrder);
        sField.setSelection(3);   // "מחיר"
        sOrder.setSelection(0);   // "עולה"

        fragment.callApplyFilter();

        assertEquals(1000, fragment.getApartmentList().get(0).get("price"));
        assertEquals(5000, fragment.getApartmentList().get(1).get("price"));
    }

    @Test
    public void resetFilter_notifiesAdapter() {
        RecyclerView.Adapter<?> mockAdapter = Mockito.mock(RecyclerView.Adapter.class);
        fragment.setAdapterForTest(mockAdapter);   // setter שיצרנו

        fragment.getAllApartments().add(Map.of("city","Beer Sheva"));

        fragment.callResetFilter();

        assertEquals(1, fragment.getApartmentList().size());
        verify(mockAdapter, times(1)).notifyDataSetChanged();
    }
}
